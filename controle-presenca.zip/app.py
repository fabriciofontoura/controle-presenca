from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from datetime import datetime, timedelta
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///controle_presenca.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Modelos de banco de dados
class Usuario(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    senha = db.Column(db.String(100), nullable=False)
    tipo = db.Column(db.String(20), nullable=False)  # 'aluno' ou 'responsavel'
    agendamentos = db.relationship('Agendamento', backref='usuario', lazy=True)

class Agendamento(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.Date, nullable=False)
    hora_inicio = db.Column(db.Time, nullable=False)
    hora_fim = db.Column(db.Time, nullable=False)
    status = db.Column(db.String(20), default='pendente')  # 'pendente', 'aprovado', 'rejeitado', 'concluido'
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)
    observacoes = db.Column(db.Text)
    data_criacao = db.Column(db.DateTime, default=datetime.utcnow)

@login_manager.user_loader
def load_user(user_id):
    return Usuario.query.get(int(user_id))

# Rotas
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        senha = request.form.get('senha')
        
        usuario = Usuario.query.filter_by(email=email).first()
        
        if usuario and usuario.senha == senha:
            login_user(usuario)
            if usuario.tipo == 'aluno':
                return redirect(url_for('dashboard_aluno'))
            else:
                return redirect(url_for('dashboard_responsavel'))
        else:
            flash('Email ou senha incorretos!')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard/aluno')
@login_required
def dashboard_aluno():
    if current_user.tipo != 'aluno':
        return redirect(url_for('dashboard_responsavel'))
    
    agendamentos = Agendamento.query.filter_by(usuario_id=current_user.id).order_by(Agendamento.data).all()
    
    # Calcular total de horas
    total_horas = 0
    for agendamento in agendamentos:
        if agendamento.status == 'concluido':
            inicio = datetime.combine(datetime.today(), agendamento.hora_inicio)
            fim = datetime.combine(datetime.today(), agendamento.hora_fim)
            duracao = (fim - inicio).total_seconds() / 3600
            total_horas += duracao
    
    return render_template('dashboard_aluno.html', agendamentos=agendamentos, total_horas=total_horas)

@app.route('/dashboard/responsavel')
@login_required
def dashboard_responsavel():
    if current_user.tipo != 'responsavel':
        return redirect(url_for('dashboard_aluno'))
    
    agendamentos_pendentes = Agendamento.query.filter_by(status='pendente').order_by(Agendamento.data).all()
    todos_agendamentos = Agendamento.query.order_by(Agendamento.data).all()
    alunos = Usuario.query.filter_by(tipo='aluno').all()
    
    # Calcular horas por aluno
    horas_por_aluno = {}
    for aluno in alunos:
        agendamentos_aluno = Agendamento.query.filter_by(usuario_id=aluno.id, status='concluido').all()
        total_horas = 0
        for agendamento in agendamentos_aluno:
            inicio = datetime.combine(datetime.today(), agendamento.hora_inicio)
            fim = datetime.combine(datetime.today(), agendamento.hora_fim)
            duracao = (fim - inicio).total_seconds() / 3600
            total_horas += duracao
        horas_por_aluno[aluno.id] = total_horas
    
    return render_template('dashboard_responsavel.html', 
                          agendamentos_pendentes=agendamentos_pendentes,
                          todos_agendamentos=todos_agendamentos,
                          alunos=alunos,
                          horas_por_aluno=horas_por_aluno)

@app.route('/agendar', methods=['GET', 'POST'])
@login_required
def agendar():
    if current_user.tipo != 'aluno':
        return redirect(url_for('dashboard_responsavel'))
    
    if request.method == 'POST':
        data_str = request.form.get('data')
        hora_inicio_str = request.form.get('hora_inicio')
        hora_fim_str = request.form.get('hora_fim')
        observacoes = request.form.get('observacoes')
        
        data = datetime.strptime(data_str, '%Y-%m-%d').date()
        hora_inicio = datetime.strptime(hora_inicio_str, '%H:%M').time()
        hora_fim = datetime.strptime(hora_fim_str, '%H:%M').time()
        
        # Verificar se a data está dentro do período permitido (15/04 a 30/06)
        data_inicio = datetime(2025, 4, 15).date()
        data_fim = datetime(2025, 6, 30).date()
        
        if data < data_inicio or data > data_fim:
            flash('A data deve estar entre 15/04/2025 e 30/06/2025!')
            return redirect(url_for('agendar'))
        
        # Verificar se é dia útil (segunda a sexta)
        if data.weekday() >= 5:  # 5=sábado, 6=domingo
            flash('Apenas dias úteis (segunda a sexta) são permitidos!')
            return redirect(url_for('agendar'))
        
        # Verificar se o horário está dentro do permitido (7h às 19h)
        hora_min = datetime.strptime('07:00', '%H:%M').time()
        hora_max = datetime.strptime('19:00', '%H:%M').time()
        
        if hora_inicio < hora_min or hora_fim > hora_max or hora_inicio >= hora_fim:
            flash('O horário deve estar entre 7h e 19h, e a hora de início deve ser anterior à hora de fim!')
            return redirect(url_for('agendar'))
        
        # Criar novo agendamento
        novo_agendamento = Agendamento(
            data=data,
            hora_inicio=hora_inicio,
            hora_fim=hora_fim,
            usuario_id=current_user.id,
            observacoes=observacoes
        )
        
        db.session.add(novo_agendamento)
        db.session.commit()
        
        flash('Agendamento realizado com sucesso! Aguardando aprovação.')
        return redirect(url_for('dashboard_aluno'))
    
    return render_template('agendar.html')

@app.route('/agendamento/<int:id>/aprovar')
@login_required
def aprovar_agendamento(id):
    if current_user.tipo != 'responsavel':
        return redirect(url_for('dashboard_aluno'))
    
    agendamento = Agendamento.query.get_or_404(id)
    agendamento.status = 'aprovado'
    db.session.commit()
    
    flash('Agendamento aprovado com sucesso!')
    return redirect(url_for('dashboard_responsavel'))

@app.route('/agendamento/<int:id>/rejeitar')
@login_required
def rejeitar_agendamento(id):
    if current_user.tipo != 'responsavel':
        return redirect(url_for('dashboard_aluno'))
    
    agendamento = Agendamento.query.get_or_404(id)
    agendamento.status = 'rejeitado'
    db.session.commit()
    
    flash('Agendamento rejeitado!')
    return redirect(url_for('dashboard_responsavel'))

@app.route('/agendamento/<int:id>/concluir')
@login_required
def concluir_agendamento(id):
    if current_user.tipo != 'responsavel':
        return redirect(url_for('dashboard_aluno'))
    
    agendamento = Agendamento.query.get_or_404(id)
    agendamento.status = 'concluido'
    db.session.commit()
    
    flash('Agendamento marcado como concluído!')
    return redirect(url_for('dashboard_responsavel'))

@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome = request.form.get('nome')
        email = request.form.get('email')
        senha = request.form.get('senha')
        tipo = request.form.get('tipo')
        
        # Verificar se o email já existe
        usuario_existente = Usuario.query.filter_by(email=email).first()
        if usuario_existente:
            flash('Email já cadastrado!')
            return redirect(url_for('cadastro'))
        
        novo_usuario = Usuario(
            nome=nome,
            email=email,
            senha=senha,
            tipo=tipo
        )
        
        db.session.add(novo_usuario)
        db.session.commit()
        
        flash('Cadastro realizado com sucesso! Faça login para continuar.')
        return redirect(url_for('login'))
    
    return render_template('cadastro.html')

# Inicialização do banco de dados
with app.app_context():
    db.create_all()
    
    # Criar usuário responsável padrão se não existir
    responsavel = Usuario.query.filter_by(email='responsavel@clinica.com').first()
    if not responsavel:
        responsavel = Usuario(
            nome='Responsável',
            email='responsavel@clinica.com',
            senha='123456',
            tipo='responsavel'
        )
        db.session.add(responsavel)
        db.session.commit()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
